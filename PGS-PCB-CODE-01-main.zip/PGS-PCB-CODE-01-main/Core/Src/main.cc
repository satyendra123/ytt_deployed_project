/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <cstring>
#include "LiquidCrystal_I2C_STM32.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define KEY_UP_RAW()   (HAL_GPIO_ReadPin(UP_KEY_GPIO_Port,  UP_KEY_Pin)  == GPIO_PIN_RESET)
#define KEY_DN_RAW()   (HAL_GPIO_ReadPin(DN_KEY_GPIO_Port,  DN_KEY_Pin)  == GPIO_PIN_RESET)
#define KEY_SFT_RAW()  (HAL_GPIO_ReadPin(SFT_KEY_GPIO_Port, SFT_KEY_Pin) == GPIO_PIN_RESET)
#define KEY_ENT_RAW()  (HAL_GPIO_ReadPin(ENT_KEY_GPIO_Port, ENT_KEY_Pin) == GPIO_PIN_RESET)
#define K_RLS   0x00
#define K_INC   0x02    // UP
#define K_DEC   0x04    // DOWN
#define K_ESC   0x06    // SHIFT
#define K_ENT   0x08    // ENTER
union{
    struct{
       unsigned Wait4KRLS:1;
       unsigned Flg_RESET4:1;

    }Flag;
    unsigned char Flags;
}KEY;
char keystt=0;


//int LCD_ScrollMenu(
//    LiquidCrystal_I2C &lcd,
//    const char *menu[],
//    uint8_t menuCount
//);

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c3;
DMA_HandleTypeDef hdma_i2c1_tx;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
//typedef enum
//{
//    KEY_NONE = 0,
//    KEY_UP,
//    KEY_DN,
//    KEY_SFT,
//    KEY_ENT
//} KEY_Event_t;
//typedef enum {
//    K_NONE = 0,
//    K_INC,
//    K_DEC,
//    K_ESC,
//    K_ENT
//} Key_t;
static uint32_t last_update = 0;
int cnt=0;

unsigned char  txbuffer[4];

#define MAX_SENSORS 10			//sensor max
#define MAX_DATA_LEN 36		//because each sensor have 4 byte length 50*4=200 +50 for noise data

typedef struct {
    unsigned char device_id;
    unsigned char data;
} SensorData;				//struct typedef for device id and data

SensorData sensors[MAX_SENSORS]; 	// array to save device id with data
unsigned char RxData6[MAX_DATA_LEN] = {				// Rx buffer to save data recive by RS485
//		////  dummy data ////
//        0x00, 0xF5, 0x03, 0x01, 0xF7, // Noise + Valid frame for Device 3
//        0xFF, 0x00, 0xF5, 0x01, 0x02, 0xF5, // Noise + Valid frame for Device 1
//        0xF5, 0x07, 0x01, 0xFB,          // Valid frame Device 7
//        0xAA, 0xBB, 0xF5, 0x02, 0x02, 0xF6,  // Noise + Valid frame Device 2
//        0xF5, 0x04, 0x01, 0xF6,          // Invalid frame (bad end byte)
//        0xF1, 0x05, 0x02, 0xF9,          // Invalid start byte
//        0x00, 0x00, 0x00, 0x00,          // Noise
//        0xF5, 0x08, 0x02, 0xFC,          // Valid frame Device 8
        // Add more data or noise as needed
    };
char device_id=0,sensor_index=0;
char timer1=0,flag1=0,timer2=0,flag2=0;
int eng = 0;
int diseng = 0;
int error = 0;
int nocom = 0;

uint8_t DIS[6];
int topIndex;     // first visible string index
int cursorPos;    // 0 ... (lcd_rows - 1)
int selected;     // topIndex + cursorPos
unsigned char prevKey = K_RLS;

char flg=0;

//const char *MenuList[] =
//{
//    "String no. 1",
//    "String no. 2",
//    "String no. 3",
//    "String no. 4",
//    "String no. 5",
//    "String no. 6",
//    "String no. 7",
//    "String no. 8",
//    "String no. 9",
//    "String no. 10"
//};
const char *MenuList[] =
{
	"String no. 1",
	"String no. 2",
	"String no. 3",
	"String no. 4",
	"String no. 5",
	"String no. 6",
	"String no. 7",
    "String no. 8",
    "String no. 9",
    "String no. 10"
};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C3_Init(void);
static void MX_TIM3_Init(void);
static void MX_UART4_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
LiquidCrystal_I2C lcd(&hi2c1, 0x27, 20, 4);
#define US_TO_CYC(us) ((us) * (SystemCoreClock / 1000000))
#define DWT_NOW()     (DWT->CYCCNT)
#define DWT_ELAPSED(start) (DWT->CYCCNT - (start))

void DWT_Init(void)
{
    // Enable TRC
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    // Reset the cycle counter
    DWT->CYCCNT = 0;
    // Enable the cycle counter
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}
//AA 01 + total sensor + emg +diseng + erorr+ no com. +FF
	/* To make request frame*/
//void build_tx_packet(uint8_t device_id)
//{
//    txbuffer[0] = 0xFA;                    // Fixed header
//    txbuffer[1] = device_id;              // Device ID
//    txbuffer[2] = 0x01;                   // Fixed command
//    txbuffer[3] = 0xF8 + device_id;       // END byte
//}
void build_tx_packet(uint8_t device_id)
{
    uint8_t sum = 3;        // initial sum for XOR checksum
    txbuffer[0] = 0xFA;     // Fixed header
    txbuffer[1] = device_id; // Device ID
    txbuffer[2] = 0x01;     // Fixed command

    // Calculate checksum: sum XOR txbuffer bytes
    sum ^= txbuffer[0];
    sum ^= txbuffer[1];
    sum ^= txbuffer[2];

    txbuffer[3] = sum;      // Checksum as END byte
}

/*This Function will send request to max sensor */
void send_scan_to_all_devices()
{
    for ( device_id = 1; device_id <= MAX_SENSORS; device_id++)
    {
        build_tx_packet(device_id);
        HAL_UART_Transmit(&huart4, txbuffer, sizeof(txbuffer),0xFFFF);
        HAL_Delay(250);  // small delay to avoid UART overlapping (adjust as needed)
    }
   timer2=0;
   flag2=1;
}



//unsigned long SetV(unsigned long Value,unsigned char BlnkPos)
//{
//unsigned char BlinkCntr,cmd,i,j;
//unsigned long Tempp;
//
//	Value%=1000000;
// 	DIS[0]=Value/100000;
//	Value%=100000;
//	DIS[1]=Value / 10000;
//	Value%=10000;
//	DIS[2]=Value / 1000;
//	Value%=1000;
//	DIS[3]=Value / 100;
//	Value%=100;
//	DIS[4]=Value / 10;
//	DIS[5]=Value % 10;
//
//	while(keystt!=K_RLS)	keystt=ReadKey(keystt);
//	HAL_Delay(1);
//
//	BlinkCntr=6-BlnkPos;
//
//	#if defined(LCD16x2)
//	ArrData[0]=DIS[0]+0x30;
//	ArrData[1]=DIS[1]+0x30;
//	ArrData[2]=DIS[2]+0x30;
//	ArrData[3]=DIS[3]+0x30;
//	ArrData[4]=DIS[4]+0x30;
//	ArrData[5]=DIS[5]+0x30;
//	cmd=0xc5;
//	for(i=0;i<6;i++)
//	{
//		Dis_Single(cmd,(ArrData[i]));
//		cmd++;
//
//		if(((5-i)==DecSP) && ((5-i)!=0))
//		{
//		Dis_Single(cmd,'.');
//		cmd++;
//		}
//	}
////	if((5-BlinkCntr)<DecSP)	Cur_ON(0xc6+BlinkCntr);
////	else	Cur_ON(0xc5+BlinkCntr);
//	#endif
//
//
//	while((keystt==K_RLS)||(keystt!=K_ENT))
//	{
////		ACTDIS[6]=DIS[0];
////		ACTDIS[7]=DIS[1];
////		ACTDIS[8]=DIS[2];
////		ACTDIS[9]=DIS[3];
////		ACTDIS[10]=DIS[4];
////		ACTDIS[11]=DIS[5];
//
//		#if defined(LCD16x2)
//         if(keystt==0)               //if(NoKeys!=0)
//		{
//		ArrData[0]=DIS[0]+0x30;
//		ArrData[1]=DIS[1]+0x30;
//		ArrData[2]=DIS[2]+0x30;
//		ArrData[3]=DIS[3]+0x30;
//		ArrData[4]=DIS[4]+0x30;
//		ArrData[5]=DIS[5]+0x30;
//		cmd=0xc5;
//		for(i=0;i<6;i++)
//		{
//			Dis_Single(cmd,(ArrData[i]));
//			cmd++;
//
//			if(((5-i)==DecSP) && ((5-i)!=0))
//			{
//			Dis_Single(cmd,'.');
//			cmd++;
//			}
//		}
////			if((5-BlinkCntr)<DecSP)	Cur_ON(0xc6+BlinkCntr);
////			else	Cur_ON(0xc5+BlinkCntr);
//		}
//         if((5-BlinkCntr)<DecSP)
//        	 {
//        	 Cur_ON(0xc6+BlinkCntr);
//        	 }
//		else	Cur_ON(0xc5+BlinkCntr);							//off kiya hai
//		#endif
//
//		#if defined(LCD12864)
//		if(!FL.Flag.FlgPrintLCD)
//		{
//		ArrData[6]=' ';
//		for(i=0,j=0;i<6;i++,j++)
//		{
//			if(((6-i)==DecSP) && ((6-i)!=0))
//			{
//			ArrData[j]='.';
//			j++;
//			}
//			ArrData[j]=DIS[i]+0x30;
//		}
//		PutTextXYSelect(40,40,ArrData,7,BlinkCntr);
//		FL.Flag.FlgPrintLCD=1;
//		}
//		#endif
//
////		if(FL.Flag.Flg500ms)
////		{
////			FL.Flag.Flg500ms=0;
////			if(FL.Flag.Blink) FL.Flag.Blink=0;
////			else FL.Flag.Blink=1;
////		}
//
//		//if(Prg.Flag.BlinkStt) ACTDIS[BlinkCntr]=10;
//
//		if(keystt!=K_RLS)		//((Key!=KeyRLS))	//	 && (Key!=KeyEnt)
//		{
//			HAL_Delay(1);
//			while(keystt!=K_RLS)	keystt=ReadKey(keystt);
//		}
//
//		keystt=ReadKey(keystt);
//		if(keystt!=K_RLS)
//		{
//		switch(keystt)
//		{
//			case K_INC:	DIS[BlinkCntr]++;
//                                        if(DIS[BlinkCntr]==10) DIS[BlinkCntr]=0;
//                                        continue;
//			case K_DEC:	if(DIS[BlinkCntr]==0) DIS[BlinkCntr]=9;
//                                        else	DIS[BlinkCntr]--;
//                                        continue;
//			case K_ESC:     BlinkCntr++;
//                                        if(BlinkCntr==6) BlinkCntr=6-BlnkPos;
//                                        continue;
//		}
//		}
////        if(ky>120) break;
//    }
//
//	//MenuNo=0;
//	//FL.Flag.FlgToKRLS=1;
//Value=DIS[0];
//Value*=100000;
//Tempp=DIS[1];
//Value+=(Tempp*10000);
//Tempp=DIS[2];
//Value+=(Tempp*1000);
//Tempp=DIS[3];
//Value+=(Tempp*100);
//Tempp=DIS[4];
//Value+=(Tempp*10);
//Value+=DIS[5];
//return(Value);
//}

unsigned char ReadKeyStt(void)
{
    unsigned char RKey = K_RLS;

    if(KEY_UP_RAW())      RKey = K_INC;
    else if(KEY_DN_RAW()) RKey = K_DEC;
    else if(KEY_SFT_RAW())RKey = K_ESC;
    else if(KEY_ENT_RAW())RKey = K_ENT;

    return RKey;
}
unsigned char ReadKey(unsigned char LastState)
{
    unsigned char Fkey, Skey;
    unsigned char SttKey = LastState;

    Fkey = ReadKeyStt();
    HAL_Delay(1);              // debounce delay (same spirit as old code)
    Skey = ReadKeyStt();

    if(Fkey == Skey)
    {
        SttKey = Fkey;
    }

    return SttKey;
}
void keyprocess(void)
{
    keystt = ReadKey(keystt);

    if(!KEY.Flag.Wait4KRLS)
    {
        switch(keystt)
        {
            case K_ESC:
                KEY.Flag.Wait4KRLS = 1;   // wait for release
                break;
            case K_INC:
                KEY.Flag.Wait4KRLS = 1;   // wait for release
                break;
            case K_DEC:
                KEY.Flag.Wait4KRLS = 1;   // wait for release
                break;
            case K_ENT:
                KEY.Flag.Wait4KRLS = 1;   // wait for release

                break;

            default:
                break;
        }
    }
    else
    {
        if(keystt == K_RLS)
        {
            KEY.Flag.Wait4KRLS = 0;       // released
        }
    }
}
static void ValueToDigits(uint32_t value, uint8_t *d)
  {
      value %= 1000000;
      d[0] = value / 100000; value %= 100000;
      d[1] = value / 10000;  value %= 10000;
      d[2] = value / 1000;   value %= 1000;
      d[3] = value / 100;    value %= 100;
      d[4] = value / 10;
      d[5] = value % 10;
  }

  static uint32_t DigitsToValue(uint8_t *d)
  {
      return  d[0]*100000UL +
              d[1]*10000UL  +
              d[2]*1000UL   +
              d[3]*100UL    +
              d[4]*10UL     +
              d[5];
  }
  void LCD_ShowDigits(LiquidCrystal_I2C &lcd,
                      uint8_t *d,
                      uint8_t blink,
                      uint8_t dec_pos)
  {
      const uint8_t start_col = 5;
      uint8_t col = start_col;
      uint8_t blink_col = start_col;

      /* clear entire field */
      lcd.setCursor(start_col, 2);
      lcd.print("         ");   // enough for 6 digits + dot

      lcd.setCursor(start_col, 2);

      for(uint8_t i = 0; i < 6; i++)
      {
          /* save cursor position for blink digit */
          if(i == blink)
              blink_col = col;

          /* print digit */
          lcd.write((char)(d[i] + '0'));
          col++;

          /* print decimal point after correct digit */
          if(dec_pos && ((5 - i) == dec_pos))
          {
              lcd.write('.');
              col++;
          }
      }
      /* place blinking cursor on correct digit */
      lcd.setCursor(blink_col, 2);
      lcd.cursor();
      lcd.blink();
  }


uint32_t SetV(uint32_t value,uint8_t disits,uint8_t dec_pos,
              LiquidCrystal_I2C &lcd)
{


    uint8_t blink_min = 6 - disits; // leftmost editable digit
    uint8_t blink_max = 5;                    // rightmost editable digit
    uint8_t blink     = blink_min;            // start at leftmost

    ValueToDigits(value, DIS);
//    lcd.clear();

    while(1)
    {
        LCD_ShowDigits(lcd, DIS, blink, dec_pos);

        /* wait for key press */
        do { keystt = ReadKey(keystt); }
        while(keystt == K_RLS);

        switch(keystt)
        {
            case K_INC:
                DIS[blink] = (DIS[blink] + 1) % 10;
                break;

            case K_DEC:
                DIS[blink] = (DIS[blink] == 0) ? 9 : DIS[blink] - 1;
                break;

            case K_ESC:   // SHIFT → move LEFT to RIGHT
                if(blink < blink_max)
                    blink++;
                else
                    blink = blink_min;   // roll over
                break;

            case K_ENT:
                lcd.noBlink();
                lcd.noCursor();
                return DigitsToValue(DIS);
        }

        /* wait for key release */
        do { keystt = ReadKey(keystt); }
        while(keystt != K_RLS);
    }
}
//int LCD_ScrollMenu(
//    LiquidCrystal_I2C &lcd,
//    const char *menu[],
//    uint8_t menuCount
//)
//{
//    int index = 0;
//    unsigned char key = K_RLS;
//    unsigned char lastKey = K_RLS;
//
//    lcd.clear();
//
//    while (1)
//    {
//        /* -------- Display Menu -------- */
//        lcd.clear();
//
//        // Line 0 (current item)
//        lcd.setCursor(0, 0);
//        lcd.print(">");
//        lcd.print(menu[index]);
//
//        // Line 1 (next item if exists)
//        if (index + 1 < menuCount)
//        {
//            lcd.setCursor(0, 1);
//            lcd.print(" ");
//            lcd.print(menu[index + 1]);
//        }
//
//        /* -------- Read Key -------- */
//        key = ReadKey(lastKey);
//        lastKey = key;
//
//        if (key == K_INC)            // UP key
//        {
//            if (index > 0)
//                index--;
//            else
//                index = menuCount - 1;   // wrap around
//        }
//        else if (key == K_DEC)       // DOWN key
//        {
//            if (index < menuCount - 1)
//                index++;
//            else
//                index = 0;               // wrap around
//        }
//        else if (key == K_ENT)       // ENTER key
//        {
//            return index;              // selected string index
//        }
//        else if (key == K_ESC)       // optional exit
//        {
//            return -1;                 // cancelled
//        }
//
//        HAL_Delay(150);  // key repeat delay
//    }
//}
//int LCD_MenuSelect(
//    LiquidCrystal_I2C &lcd,
//    const char *menu[],
//    uint8_t menuCount
//)
//{
//	uint8_t rows = lcd.getRows();     // auto detect 2 or 4 line
//    int topIndex = 0;
//    int cursorPos = 0;
//
//    unsigned char key = K_RLS;
//    unsigned char lastKey = K_RLS;
//
//    lcd.clear();
//
//    while (1)
//    {
//        /* -------- Draw Screen -------- */
//        lcd.clear();
//
//        for (uint8_t i = 0; i < rows; i++)
//        {
//            int itemIndex = topIndex + i;
//            if (itemIndex >= menuCount)
//                break;
//
//            lcd.setCursor(0, i);
//
//            if (i == cursorPos)
//                lcd.print(">");
//            else
//                lcd.print(" ");
//
//            lcd.print(menu[itemIndex]);
//        }
//
//        /* -------- Read Key -------- */
//        key = ReadKey(lastKey);
//        lastKey = key;
//
//        /* -------- UP key -------- */
//        if (key == K_INC)
//        {
//            if (cursorPos > 0)
//            {
//                cursorPos--;          // move cursor only
//            }
//            else if (topIndex > 0)
//            {
//                topIndex--;           // scroll list up
//            }
//        }
//
//        /* -------- DOWN key -------- */
//        else if (key == K_DEC)
//        {
//            if (cursorPos < (rows - 1) &&
//                (topIndex + cursorPos + 1) < menuCount)
//            {
//                cursorPos++;          // move cursor only
//            }
//            else if ((topIndex + rows) < menuCount)
//            {
//                topIndex++;           // scroll list down
//            }
//        }
//
//        /* -------- ENTER -------- */
//        else if (key == K_ENT)
//        {
//            return (topIndex + cursorPos);
//        }
//
//        /* -------- ESC -------- */
//        else if (key == K_ESC)
//        {
//            return -1;
//        }
//
////        HAL_Delay(120);   // smooth key handling
//    }
//}
//int LCD_MenuSelect(
//    LiquidCrystal_I2C &lcd,
//    const char *menu[],
//    uint8_t menuCount
//)
//{
//    uint8_t rows = lcd.getRows();
//
//    int topIndex = 0;
//    int cursorPos = 0;
//
//    int prevTop = -1;
//    int prevCursor = -1;
//
//    unsigned char key = K_RLS;
//    unsigned char lastKey = K_RLS;
//
//    lcd.clear();
//
//    while (1)
//    {
//        /* -------- Draw only if needed -------- */
//        if ((topIndex != prevTop) || (cursorPos != prevCursor))
//        {
//            for (uint8_t i = 0; i < rows; i++)
//            {
//                lcd.setCursor(0, i);
//
//                int itemIndex = topIndex + i;
//
//                if (itemIndex < menuCount)
//                {
//                    if (i == cursorPos)
//                        lcd.print(">");
//                    else
//                        lcd.print(" ");
//
//                    lcd.print(menu[itemIndex]);
//                }
//                else
//                {
//                    lcd.print("                "); // clear line
//                }
//            }
//
//            prevTop = topIndex;
//            prevCursor = cursorPos;
//        }
//
//        /* -------- Read Key -------- */
//        key = ReadKey(lastKey);
//        lastKey = key;
//
//        /* -------- UP -------- */
//        if (key == K_INC)
//        {
//            if (cursorPos > 0)
//                cursorPos--;
//            else if (topIndex > 0)
//                topIndex--;
//        }
//
//        /* -------- DOWN -------- */
//        else if (key == K_DEC)
//        {
//            if (cursorPos < (rows - 1) &&
//                (topIndex + cursorPos + 1) < menuCount)
//            {
//                cursorPos++;
//            }
//            else if ((topIndex + rows) < menuCount)
//            {
//                topIndex++;
//            }
//        }
//
//        /* -------- ENTER -------- */
//        else if (key == K_ENT)
//        {
//            return (topIndex + cursorPos);
//        }
//
//        /* -------- ESC -------- */
//        else if (key == K_ESC)
//        {
//            return -1;
//        }
//
//        HAL_Delay(120);   // small debounce / CPU relief
//    }
//}
int LCD_MenuSelect(
    LiquidCrystal_I2C &lcd,
    const char *menu[],
    uint8_t menuCount
)
{
    uint8_t rows = lcd.getRows();

    int topIndex = 0;
    int cursorPos = 0;

    int prevTop = -1;
    int prevCursor = -1;

    unsigned char key = K_RLS;
    unsigned char lastKey = K_RLS;
    unsigned char prevKey = K_RLS;

    lcd.clear();

    while (1)
    {
        /* -------- Draw only if needed -------- */
        if ((topIndex != prevTop) || (cursorPos != prevCursor))
        {
            for (uint8_t i = 0; i < rows; i++)
            {
                lcd.setCursor(0, i);
                int itemIndex = topIndex + i;

                if (itemIndex < menuCount)
                {
                    lcd.print(i == cursorPos ? ">" : " ");
                    lcd.print(menu[itemIndex]);
                }
                else
                {
                    lcd.print("                ");
                }
            }

            prevTop = topIndex;
            prevCursor = cursorPos;
        }

        /* -------- Key EDGE detect -------- */
        key = ReadKey(lastKey);
        lastKey = key;

        if (key == prevKey)
            continue;   // ignore hold

        prevKey = key;

        /* -------- UP -------- */
        if (key == K_INC)
        {
            if (cursorPos > 0)
                cursorPos--;
            else if (topIndex > 0)
                topIndex--;
        }

        /* -------- DOWN -------- */
        else if (key == K_DEC)
        {
            if (cursorPos < (rows - 1) &&
                (topIndex + cursorPos + 1) < menuCount)
                cursorPos++;
            else if ((topIndex + rows) < menuCount)
                topIndex++;
        }

        /* -------- ENTER -------- */
        else if (key == K_ENT)
        {
            return (topIndex + cursorPos);
        }

        /* -------- ESC -------- */
        else if (key == K_ESC)
        {
            return -1;
        }
    }
}


void LCD_Show(uint8_t TS, uint8_t TO,uint8_t TV, uint8_t TE, uint8_t NC)
{
    char buf[21];
    if (DWT_ELAPSED(last_update) > 1000)// 5000us = 5ms
	  {
		  if( flg==0)
		  {
			  // Examples:
//			  uint32_t setpoint;
//			      lcd.clear();
//			  lcd.setCursor(0,0);
//			  lcd.print("   SET BAUD RATE   ");
//			  setpoint = SetV(12345,     // initial value
//			                 6,         // start blinking from right
//			                  0,         // decimal position
//			                  lcd);      // your LCD object
//			  int selected;
//
//			  selected = LCD_MenuSelect(lcd, MenuList, 10);
//
//			  if (selected >= 0)
//			  {
//			      lcd.clear();
//			      lcd.print("Selected:");
//			      lcd.setCursor(0, 1);
//			      lcd.print(MenuList[selected]);
//			  }

			  lcd.clear();
			  lcd.setCursor(0,0);
			  lcd.print("   HOUSTON SYSTEM   ");
			  lcd.setCursor(0,1);
			  lcd.print("********************");
			  flg=1;
			  }
	  }
    // Line 3: Disengaged + Error
    lcd.setCursor(0, 2);
    snprintf(buf, sizeof(buf), "TS=%02d TO=%02d TV=%02d", TS, TO, TV);
   lcd.print(buf);

    // Line 4: Total + Engaged + NoComm
    lcd.setCursor(0, 3);
    snprintf(buf, sizeof(buf), "    TE=%02d  NC=%02d   ", TE, NC);
   lcd.print(buf);

}

void LCD_ShowInitScreen(void)
{

    lcd.setCursor(0,0);
    lcd.print("   HOUSTON SYSTEM   ");

    lcd.setCursor(0,1);
    lcd.print("********************");

    lcd.setCursor(0,2);
    lcd.print("PARKING GUIDANCE SYS");

    lcd.setCursor(0,3);
    lcd.print("INITIALIZING      "); // spaces important
}
void LCD_InitDots(uint8_t dots)
{
    lcd.setCursor(12, 3);   // after "INITIALIZING"
    for(uint8_t i = 0; i < dots; i++)
        lcd.print(".");
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_I2C3_Init();
  MX_TIM3_Init();
  MX_UART4_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  DWT_Init();
  lcd.begin(20, 4);
  lcd.backlight();
  lcd.clear();
  //UART 4 is for sensor // uart 2 for display // uart 1 for main controller//
  HAL_UART_Receive_IT(&huart4,RxData6,MAX_DATA_LEN);
  HAL_TIM_Base_Start_IT(&htim3);
  LCD_ShowInitScreen();
  for(uint8_t i = 1; i <= 6; i++)
  {
      LCD_InitDots(i);
//      HAL_Delay(700);   // 👈 slow increase (adjust speed)
  }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  while (1)
  {
//	  LCD_Show( 1, 2, 3, 4, 5);
	  if(flag1)
	  {
		  send_scan_to_all_devices();
		  timer1=0;
		  flag1=0;
	  }
		  if((timer2>2)&&(flag2))
		  {
			  for (int i = 0; i <= 36 - 4; )
			  {
					  if (RxData6[i] == 0xF5)
					  {
						  unsigned char device_id = RxData6[i + 1];
						  unsigned char data = RxData6[i + 2];
						  unsigned char end_byte = RxData6[i + 3];
						  unsigned char checksum=0x3^0xF5;
						  checksum ^= device_id;
						  checksum^=data;
	 //		              if (end_byte == (0xF4 + device_id))
						  if (end_byte ==checksum)
						  {
							  // Valid frame found
							  if (sensor_index < MAX_SENSORS)
							  {
								  sensors[sensor_index].device_id = device_id;
								  sensors[sensor_index].data = data;
								  sensor_index++;
							  }
							  i += 4;  // Skip past the full frame
						  }
						  else
						  {
							  i++;  // Invalid frame, move one byte
						  }
					  }
					  else
					  {
						  i++;  // Not a frame start, move one byte
					  }
				  }
				  for (int i = 0; i < MAX_SENSORS; i++)
				  {
					  switch (sensors[i].data) {
						  case 0x01:
							  eng++;
							  break;
						  case 0x02:
							  diseng++;
							  break;
						  case 0x03:
							  error++;
							  break;
						  default:
							  nocom++;
							  break;
					  }
				  }
					char maintx[100];
					char lcdtx[100];
					char clear[20];
					int total = eng + diseng + error + nocom;
					LCD_Show( total, eng, diseng, error, nocom);
					snprintf(maintx, sizeof(maintx), "AA01%02d%02d%02d%02d%02dFF", total, eng, diseng, error, nocom);
//					snprintf(lcdtx, sizeof(lcdtx), "|AA|01|%02d|%02d|%02d|%02d|55|", total, eng, diseng, error); //|C|1|4|1|30-0-#u#R9|
					snprintf(clear, sizeof(clear), "|C|1|6|"); //|C|1|4|1|30-0-#u#R9|
					snprintf(lcdtx, sizeof(lcdtx), "|C|1|4|1|28-0-#u#G%d|", diseng); //|C|1|4|1|30-0-#u#R9|


					HAL_UART_Transmit(&huart1, (uint8_t*)maintx, strlen(maintx),0xFFFF);
					HAL_UART_Transmit(&huart2, (uint8_t*)clear, strlen(clear),0xFFFF);
					HAL_Delay(300);
					HAL_UART_Transmit(&huart2, (uint8_t*)lcdtx, strlen(lcdtx),0xFFFF);
					flag1=0;			// to trigger send request
					timer1=0;
					timer2=0;
					flag2=0;
					sensor_index=0;			//total get sensor
					memset(sensors, 0, sizeof(sensors));
					memset(RxData6, 0, MAX_DATA_LEN);
					eng = 0;
					diseng = 0;
					error = 0;
					nocom = 0;
					HAL_UART_Receive_IT(&huart4, RxData6, MAX_DATA_LEN);
		  }
//	  }
	  cnt++;
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 240;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLRCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C3_Init(void)
{

  /* USER CODE BEGIN I2C3_Init 0 */

  /* USER CODE END I2C3_Init 0 */

  /* USER CODE BEGIN I2C3_Init 1 */

  /* USER CODE END I2C3_Init 1 */
  hi2c3.Instance = I2C3;
  hi2c3.Init.ClockSpeed = 400000;
  hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c3.Init.OwnAddress1 = 0;
  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c3.Init.OwnAddress2 = 0;
  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C3_Init 2 */

  /* USER CODE END I2C3_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 62499;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1439;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 9600;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin : DN_KEY_Pin */
  GPIO_InitStruct.Pin = DN_KEY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DN_KEY_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : UP_KEY_Pin ENT_KEY_Pin SFT_KEY_Pin */
  GPIO_InitStruct.Pin = UP_KEY_Pin|ENT_KEY_Pin|SFT_KEY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if(huart->Instance==UART4)
   	{

//    	HAL_UARTEx_ReceiveToIdle_IT(&huart6,RxData6,4);
    	HAL_UART_Receive_IT(&huart4, RxData6, MAX_DATA_LEN);
//    	HAL_UART_Transmit(&huart4, RxData6,6,0xFFFF);

   	}
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef* htim)
{
	timer1++;
	timer2++;
	if (timer1>35)			//Every 30 sec timer1 will reset and send max sensor requests////
	{
		flag1=1;
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
